export const environment = {
  production: true,
  apiUrl: '//localhost:9001',
  appTitle: 'Qa App'
};
