import { HighlightSearchPipe } from './highlight-search.pipe';

describe('HighlightSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new HighlightSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
