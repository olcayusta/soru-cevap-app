import { StickyDirective } from './sticky.directive';

describe('StickyDirective', () => {
  it('should create an instance', () => {
    const directive = new StickyDirective();
    expect(directive).toBeTruthy();
  });
});
