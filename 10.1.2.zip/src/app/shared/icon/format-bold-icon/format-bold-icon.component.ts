import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'qa-format-bold-icon',
  templateUrl: './format-bold-icon.component.html',
  styleUrls: ['./format-bold-icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FormatBoldIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
