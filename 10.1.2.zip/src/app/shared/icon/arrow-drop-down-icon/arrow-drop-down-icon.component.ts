import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'qa-arrow-drop-down-icon',
  templateUrl: 'arrow_drop_down-24px.svg',
  styles: [`:host {
    display: inline-flex;
  }`],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ArrowDropDownIconComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
